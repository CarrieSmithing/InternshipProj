import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.ParseException;
import org.json.simple.parser.JSONParser;
import java.io.*;
import java.util.Scanner;


public class  Flowers{
    public static void main(String[] args) {
        Scanner scan = new Scanner (System.in);
        JSONParser parser = new JSONParser();
        try {
            URL url = new URL("https://jsonplaceholder.typicode.com/posts/1/comments");
            BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
            String str = "";
            String s = "";
            //prints Json array if you want remove uncomment it out
            /*while (null != (str = br.readLine())) {
                 System.out.println(str);
                s = s+str;
            }*/
            //creating Json Array
            JSONArray a = (JSONArray) parser.parse(s);
            //first line of CSV to system output
            System.out.println("\"postId\", \"id\", \"name\", \"email\", \"body\"");
            String ss = "\"postId\", \"id\", \"name\", \"email\", \"body\"";
            //file for CSV to be put on file
            String text = new String();
            System.out.println("\nHi please put in the name of the file you would like the CSV to be copied to: ");
            System.out.println("(if you want you can use the file named Csv.txt that is in the program.)");
            System.out.println("(if you choose another file please add it to the program's package)");
            text = scan.nextLine();
            File target = new File (text);
            PrintWriter os = new PrintWriter (target);
            os.println(ss);
            // Loop that creates each Json object for the array 
            // and that prints the CSV file
                for (Object o : a) {
                    JSONObject tutorials = (JSONObject) o;

                    Long Pid = (Long) tutorials.get("postId");
                    System.out.print("\""+Pid+"\", ");
                     
                    Long id = (Long) tutorials.get("id");
                    System.out.print("\""+id+"\", ");

                    String name = (String) tutorials.get("name");
                    System.out.print("\""+name+"\", ");
                    
                    String email = (String) tutorials.get("email");
                    System.out.print("\""+email+"\", ");
                    
                    String body = (String) tutorials.get("body");
                    System.out.print("\""+body+"\" ");

                    System.out.println("\n");
                    
                    //CSV file
                    os.println("\""+Pid+"\", " + "\""+id+"\", " + "\""+name+"\", " + "\""+email+"\", "+"\""+body+"\"");
                    os.println();
                }
            System.out.println();
            System.out.println("Please open the file you chose");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
           
    }
}